package p.lodz.Exceptions;

public class InvalidValueException extends RuntimeException {
    public InvalidValueException(String msg) {
        super(msg);
    }
}
